# CodeWizard Development Platform

## Overview

CodeWizard is a full-stack web application that serves as a comprehensive development platform. It provides users with project exploration capabilities, an integrated code editor, AI-powered coding assistance, and code snapshot management. The platform is built as a single-page application with user authentication, project management from GitHub, and AI integration for enhanced development experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type-safe component development
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent design
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Styling**: Tailwind CSS with custom CSS variables for theming and responsive design
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript for REST API endpoints
- **Authentication**: Replit Auth integration using OpenID Connect with session management
- **Session Storage**: PostgreSQL-based session store using connect-pg-simple
- **Database ORM**: Drizzle ORM for type-safe database operations
- **API Structure**: RESTful endpoints for user management, projects, AI chat, and code snapshots

### Data Storage Solutions
- **Primary Database**: PostgreSQL with Neon serverless driver for scalable cloud database
- **Database Schema**: 
  - Users table for authentication and profile data
  - Projects table for caching GitHub repository information
  - Code snapshots table for saving and sharing code snippets
  - Sessions table for secure session management
- **Migration System**: Drizzle Kit for database schema management and migrations

### Authentication and Authorization
- **Provider**: Replit Auth using OpenID Connect protocol
- **Session Management**: Express sessions with PostgreSQL storage
- **Authorization Pattern**: Middleware-based authentication checking for protected routes
- **User Data**: JWT claims processing with user profile management

### External Service Integrations
- **AI Services**: OpenAI GPT-4o integration for code assistance and explanation features
- **Version Control**: GitHub API integration for fetching and caching public repositories
- **Image Hosting**: Supports external profile images via URL storage
- **Development Tools**: Replit-specific integrations for development environment

### Key Architectural Decisions

**Monorepo Structure**: Organized with separate client, server, and shared directories for clear separation of concerns while enabling code sharing through shared schema definitions.

**Type Safety**: Full TypeScript implementation across frontend, backend, and shared schemas with Zod validation for runtime type checking.

**Caching Strategy**: TanStack Query provides intelligent client-side caching with GitHub API data cached in PostgreSQL to reduce external API calls.

**Component Architecture**: Modular UI components using Radix primitives for accessibility with custom styling through Tailwind CSS and CSS variables for theme consistency.

**Error Handling**: Centralized error handling with toast notifications and proper HTTP status codes throughout the application.

**Development Experience**: Hot module replacement via Vite, TypeScript checking, and Replit-specific development tools for enhanced developer productivity.