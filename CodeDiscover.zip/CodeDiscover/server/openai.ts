import OpenAI from "openai";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "sk-default-key"
});

export async function generateAIResponse(message: string, context?: string): Promise<string> {
  try {
    const systemPrompt = `You are CodeWizard AI, a helpful coding assistant. You help developers with:
    - Code explanations and debugging
    - Best practices and optimization
    - Technology recommendations
    - Project architecture advice
    - Learning resources
    
    Keep responses concise but informative. Use a friendly, professional tone.
    ${context ? `Context: ${context}` : ''}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't generate a response.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate AI response");
  }
}

export async function explainCode(code: string, language: string): Promise<string> {
  try {
    const prompt = `Explain this ${language} code in simple terms:

\`\`\`${language}
${code}
\`\`\`

Provide a clear, beginner-friendly explanation of what this code does.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      max_tokens: 400,
      temperature: 0.3,
    });

    return response.choices[0].message.content || "Unable to explain this code.";
  } catch (error) {
    console.error("OpenAI code explanation error:", error);
    throw new Error("Failed to explain code");
  }
}
