import { Code } from "lucide-react";

export default function AppLoader() {
  return (
    <div className="fixed inset-0 bg-white dark:bg-dark-bg z-50 flex items-center justify-center">
      <div className="text-center">
        <div className="inline-flex items-center space-x-2 mb-4">
          <Code className="h-8 w-8 text-brand-500 animate-spin" />
          <span className="text-2xl font-bold text-brand-500">CodeWizard</span>
        </div>
        <div className="w-32 h-1 bg-gray-200 dark:bg-dark-border rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-brand-500 to-purple-500 rounded-full animate-pulse"></div>
        </div>
        <p className="text-sm text-gray-500 dark:text-dark-muted mt-2">
          Initializing your workspace...
        </p>
      </div>
    </div>
  );
}
