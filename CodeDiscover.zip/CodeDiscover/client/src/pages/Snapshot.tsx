import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Copy, Download, Loader2, Camera } from "lucide-react";

const languages = [
  "javascript",
  "typescript", 
  "python",
  "java",
  "html",
  "css",
  "cpp",
  "c",
  "php",
  "ruby",
  "go",
  "rust",
];

const themes = [
  { value: "vs-dark", label: "VS Code Dark" },
  { value: "vs-light", label: "VS Code Light" },
  { value: "github-dark", label: "GitHub Dark" },
  { value: "github-light", label: "GitHub Light" },
  { value: "monokai", label: "Monokai" },
  { value: "dracula", label: "Dracula" },
];

const sampleCode = `function fibonacci(n) {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

console.log(fibonacci(10));`;

export default function Snapshot() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    title: "",
    language: "javascript",
    theme: "vs-dark", 
    code: sampleCode,
  });

  const createSnapshotMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/snapshots", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Code snapshot created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create snapshot. Please try again.",
        variant: "destructive",
      });
    },
  });

  const generateSnapshot = () => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to create snapshots.",
        variant: "destructive",
      });
      return;
    }
    
    createSnapshotMutation.mutate(formData);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(formData.code);
    toast({
      title: "Copied!",
      description: "Code copied to clipboard.",
    });
  };

  const exportSnapshot = () => {
    // Create a canvas element to generate the image
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    if (!ctx) {
      toast({
        title: "Error",
        description: "Unable to generate snapshot. Canvas not supported.",
        variant: "destructive",
      });
      return;
    }

    // Set canvas dimensions
    canvas.width = 800;
    canvas.height = 600;

    // Background
    const bgColor = formData.theme.includes('dark') ? '#1e1e1e' : '#ffffff';
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Header with title
    ctx.fillStyle = formData.theme.includes('dark') ? '#ffffff' : '#000000';
    ctx.font = 'bold 18px Monaco, Consolas, monospace';
    if (formData.title) {
      ctx.fillText(formData.title, 20, 40);
    }

    // Language badge
    ctx.fillStyle = '#007acc';
    ctx.fillRect(20, 60, 100, 25);
    ctx.fillStyle = '#ffffff';
    ctx.font = '12px Monaco, Consolas, monospace';
    ctx.fillText(formData.language.toUpperCase(), 25, 77);

    // Code content
    ctx.fillStyle = formData.theme.includes('dark') ? '#d4d4d4' : '#333333';
    ctx.font = '14px Monaco, Consolas, monospace';
    
    const lines = formData.code.split('\n');
    const lineHeight = 20;
    const startY = 110;
    
    lines.slice(0, 20).forEach((line, index) => { // Limit to 20 lines
      const y = startY + (index * lineHeight);
      if (y < canvas.height - 20) {
        ctx.fillText(line, 20, y);
      }
    });

    // Convert canvas to blob and download
    canvas.toBlob((blob) => {
      if (!blob) {
        toast({
          title: "Error",
          description: "Failed to generate image.",
          variant: "destructive",
        });
        return;
      }

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${formData.title || 'code-snapshot'}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast({
        title: "Success",
        description: "Code snapshot exported successfully!",
      });
    }, 'image/png');
  };

  const getLanguageColor = (language: string) => {
    const colors: Record<string, string> = {
      javascript: "text-yellow-400",
      typescript: "text-blue-400", 
      python: "text-green-400",
      java: "text-red-400",
      html: "text-orange-400",
      css: "text-purple-400",
      cpp: "text-pink-400",
    };
    return colors[language] || "text-gray-400";
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-dark-text mb-4">
          Code Snapshot
        </h1>
        <p className="text-gray-600 dark:text-dark-muted">
          Create beautiful screenshots of your code
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Code Input */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Camera className="h-5 w-5 mr-2" />
                Configure Snapshot
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title (Optional)</Label>
                <input
                  id="title"
                  type="text"
                  placeholder="My awesome code"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-dark-border rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent bg-white dark:bg-dark-elevated text-gray-900 dark:text-dark-text"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <Select value={formData.language} onValueChange={(value) => setFormData(prev => ({ ...prev, language: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map((lang) => (
                        <SelectItem key={lang} value={lang}>
                          {lang.charAt(0).toUpperCase() + lang.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="theme">Theme</Label>
                  <Select value={formData.theme} onValueChange={(value) => setFormData(prev => ({ ...prev, theme: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {themes.map((theme) => (
                        <SelectItem key={theme.value} value={theme.value}>
                          {theme.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="code">Code</Label>
                <Textarea
                  id="code"
                  rows={12}
                  value={formData.code}
                  onChange={(e) => setFormData(prev => ({ ...prev, code: e.target.value }))}
                  placeholder="Paste your code here..."
                  className="font-mono text-sm"
                />
              </div>

              <Button
                onClick={generateSnapshot}
                disabled={createSnapshotMutation.isPending || !formData.code.trim()}
                className="w-full"
              >
                {createSnapshotMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Camera className="h-4 w-4 mr-2" />
                    Generate Snapshot
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Preview */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Preview</CardTitle>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={copyToClipboard}>
                    <Copy className="h-4 w-4 mr-2" />
                    Copy
                  </Button>
                  <Button size="sm" onClick={exportSnapshot}>
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Code Preview with syntax highlighting simulation */}
              <div className="bg-gray-900 rounded-lg p-4 overflow-hidden">
                {/* Window Controls */}
                <div className="flex items-center space-x-2 mb-4">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-gray-400 text-sm ml-4">
                    {formData.title || `code.${formData.language}`}
                  </span>
                </div>

                {/* Code Content */}
                <div className="font-mono text-sm">
                  <pre className="text-gray-300 whitespace-pre-wrap">
                    {formData.code.split('\n').map((line, index) => (
                      <div key={index} className="flex">
                        <span className="text-gray-500 select-none w-8 flex-shrink-0 text-right mr-4">
                          {index + 1}
                        </span>
                        <span className={getLanguageColor(formData.language)}>
                          {line || '\u00A0'}
                        </span>
                      </div>
                    ))}
                  </pre>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
