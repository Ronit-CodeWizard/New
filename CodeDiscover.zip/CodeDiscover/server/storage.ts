import {
  users,
  projects,
  codeSnapshots,
  type User,
  type UpsertUser,
  type Project,
  type InsertProject,
  type CodeSnapshot,
  type InsertCodeSnapshot,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, userData: Partial<User>): Promise<User>;
  
  // Project operations
  getProjects(): Promise<Project[]>;
  upsertProject(project: InsertProject): Promise<Project>;
  getProjectsByLanguage(language: string): Promise<Project[]>;
  
  // Code snapshot operations
  getCodeSnapshots(userId: string): Promise<CodeSnapshot[]>;
  createCodeSnapshot(snapshot: InsertCodeSnapshot): Promise<CodeSnapshot>;
  getCodeSnapshot(id: string): Promise<CodeSnapshot | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUser(id: string, userData: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...userData, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Project operations
  async getProjects(): Promise<Project[]> {
    return await db
      .select()
      .from(projects)
      .orderBy(desc(projects.stargazersCount));
  }

  async upsertProject(projectData: InsertProject): Promise<Project> {
    const [project] = await db
      .insert(projects)
      .values(projectData)
      .onConflictDoUpdate({
        target: projects.githubId,
        set: {
          ...projectData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return project;
  }

  async getProjectsByLanguage(language: string): Promise<Project[]> {
    return await db
      .select()
      .from(projects)
      .where(eq(projects.language, language))
      .orderBy(desc(projects.stargazersCount));
  }

  // Code snapshot operations
  async getCodeSnapshots(userId: string): Promise<CodeSnapshot[]> {
    return await db
      .select()
      .from(codeSnapshots)
      .where(eq(codeSnapshots.userId, userId))
      .orderBy(desc(codeSnapshots.createdAt));
  }

  async createCodeSnapshot(snapshotData: InsertCodeSnapshot): Promise<CodeSnapshot> {
    const [snapshot] = await db
      .insert(codeSnapshots)
      .values(snapshotData)
      .returning();
    return snapshot;
  }

  async getCodeSnapshot(id: string): Promise<CodeSnapshot | undefined> {
    const [snapshot] = await db
      .select()
      .from(codeSnapshots)
      .where(eq(codeSnapshots.id, id));
    return snapshot;
  }
}

export const storage = new DatabaseStorage();
