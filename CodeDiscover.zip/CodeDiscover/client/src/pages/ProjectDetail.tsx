import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Star, 
  GitFork, 
  Eye,
  Download,
  ExternalLink,
  Github,
  Calendar,
  Clock,
  Users,
  Code,
  FileText,
  Activity,
  Settings,
  Share,
  Play,
  BookOpen,
  Zap,
  TrendingUp
} from "lucide-react";

interface ProjectStats {
  commits: number;
  contributors: number;
  languages: { [key: string]: number };
  fileCount: number;
  lastActivity: Date;
  codeQuality: number;
  testCoverage: number;
  documentation: number;
}

interface Contributor {
  id: string;
  username: string;
  avatar: string;
  commits: number;
  additions: number;
  deletions: number;
  role: "owner" | "maintainer" | "contributor";
}

interface ProjectFile {
  name: string;
  type: "file" | "directory";
  size: number;
  lastModified: Date;
  path: string;
}

// Mock data for demonstration
const projectStats: ProjectStats = {
  commits: 247,
  contributors: 5,
  languages: {
    "TypeScript": 65,
    "JavaScript": 20,
    "CSS": 10,
    "HTML": 5
  },
  fileCount: 156,
  lastActivity: new Date(Date.now() - 2 * 60 * 60 * 1000),
  codeQuality: 92,
  testCoverage: 85,
  documentation: 78
};

const contributors: Contributor[] = [
  {
    id: "1",
    username: "ronit-codewizard",
    avatar: "https://github.com/ronit-codewizard.png",
    commits: 156,
    additions: 12543,
    deletions: 3421,
    role: "owner"
  },
  {
    id: "2",
    username: "jane-developer",
    avatar: "https://api.dicebear.com/7.x/avatars/svg?seed=jane",
    commits: 45,
    additions: 4532,
    deletions: 1234,
    role: "maintainer"
  },
  {
    id: "3",
    username: "alex-coder",
    avatar: "https://api.dicebear.com/7.x/avatars/svg?seed=alex",
    commits: 28,
    additions: 2134,
    deletions: 867,
    role: "contributor"
  },
  {
    id: "4", 
    username: "sarah-dev",
    avatar: "https://api.dicebear.com/7.x/avatars/svg?seed=sarah",
    commits: 12,
    additions: 876,
    deletions: 234,
    role: "contributor"
  },
  {
    id: "5",
    username: "mike-engineer",
    avatar: "https://api.dicebear.com/7.x/avatars/svg?seed=mike",
    commits: 6,
    additions: 432,
    deletions: 123,
    role: "contributor"
  }
];

const projectFiles: ProjectFile[] = [
  { name: "src", type: "directory", size: 0, lastModified: new Date(), path: "/src" },
  { name: "components", type: "directory", size: 0, lastModified: new Date(), path: "/src/components" },
  { name: "pages", type: "directory", size: 0, lastModified: new Date(), path: "/src/pages" },
  { name: "utils", type: "directory", size: 0, lastModified: new Date(), path: "/src/utils" },
  { name: "App.tsx", type: "file", size: 2456, lastModified: new Date(), path: "/src/App.tsx" },
  { name: "index.tsx", type: "file", size: 384, lastModified: new Date(), path: "/src/index.tsx" },
  { name: "package.json", type: "file", size: 1234, lastModified: new Date(), path: "/package.json" },
  { name: "README.md", type: "file", size: 3456, lastModified: new Date(), path: "/README.md" },
  { name: "tsconfig.json", type: "file", size: 567, lastModified: new Date(), path: "/tsconfig.json" },
  { name: ".gitignore", type: "file", size: 234, lastModified: new Date(), path: "/.gitignore" }
];

const commitActivity = [
  { date: "2024-01-15", commits: 8 },
  { date: "2024-01-16", commits: 12 },
  { date: "2024-01-17", commits: 6 },
  { date: "2024-01-18", commits: 15 },
  { date: "2024-01-19", commits: 9 },
  { date: "2024-01-20", commits: 11 },
  { date: "2024-01-21", commits: 7 }
];

export default function ProjectDetail({ params }: { params: { id: string } }) {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isStarred, setIsStarred] = useState(false);

  const { data: projects = [] } = useQuery({
    queryKey: ["/api/projects"],
    enabled: isAuthenticated,
  });

  // Find the specific project (in a real app, you'd fetch by ID)
  const project = projects.find(p => p.id === params?.id) || projects[0];

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized", 
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const starMutation = useMutation({
    mutationFn: async () => {
      // In a real app, this would make an API call to star/unstar
      await new Promise(resolve => setTimeout(resolve, 500));
      return !isStarred;
    },
    onSuccess: (newStarredState) => {
      setIsStarred(newStarredState);
      toast({
        title: newStarredState ? "Starred!" : "Unstarred",
        description: `Project ${newStarredState ? 'added to' : 'removed from'} your starred list.`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update star status.",
        variant: "destructive",
      });
    },
  });

  const getRoleColor = (role: string) => {
    switch (role) {
      case "owner": return "bg-red-100 text-red-600 dark:bg-red-500/20 dark:text-red-400";
      case "maintainer": return "bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400";
      case "contributor": return "bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400";
      default: return "bg-gray-100 text-gray-600 dark:bg-gray-500/20 dark:text-gray-400";
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-dark-muted">Loading project...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !project) {
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Project Header */}
      <div className="mb-8">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-16 h-16 bg-brand-100 dark:bg-brand-500/20 rounded-xl flex items-center justify-center">
                <Code className="h-8 w-8 text-brand-500" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900 dark:text-dark-text">
                  {project.name}
                </h1>
                <p className="text-gray-600 dark:text-dark-muted mt-1">
                  {project.description || "No description available"}
                </p>
              </div>
            </div>
            
            <div className="flex flex-wrap items-center gap-4 mb-6">
              {project.language && (
                <Badge className="bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400">
                  {project.language}
                </Badge>
              )}
              <Badge variant="secondary">Public</Badge>
              <div className="flex items-center text-sm text-gray-600 dark:text-dark-muted">
                <Star className="h-4 w-4 mr-1" />
                {project.stargazersCount} stars
              </div>
              <div className="flex items-center text-sm text-gray-600 dark:text-dark-muted">
                <GitFork className="h-4 w-4 mr-1" />
                {project.forksCount} forks
              </div>
              <div className="flex items-center text-sm text-gray-600 dark:text-dark-muted">
                <Eye className="h-4 w-4 mr-1" />
                {Math.floor(Math.random() * 1000) + 100} watchers
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 lg:ml-6">
            <Button
              variant={isStarred ? "default" : "outline"}
              onClick={() => starMutation.mutate()}
              disabled={starMutation.isPending}
            >
              <Star className={`h-4 w-4 mr-2 ${isStarred ? 'fill-current' : ''}`} />
              {starMutation.isPending ? "..." : (isStarred ? "Starred" : "Star")}
            </Button>
            <Button variant="outline">
              <GitFork className="h-4 w-4 mr-2" />
              Fork
            </Button>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Clone
            </Button>
            <Button onClick={() => window.open(project.htmlUrl, "_blank")}>
              <ExternalLink className="h-4 w-4 mr-2" />
              View on GitHub
            </Button>
          </div>
        </div>
      </div>

      {/* Project Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-dark-muted">Total Commits</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">{projectStats.commits}</p>
              </div>
              <Activity className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-dark-muted">Contributors</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">{projectStats.contributors}</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-dark-muted">Files</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">{projectStats.fileCount}</p>
              </div>
              <FileText className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-dark-muted">Code Quality</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">{projectStats.codeQuality}%</p>
              </div>
              <Zap className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="files">Files</TabsTrigger>
          <TabsTrigger value="contributors">Contributors</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              {/* README */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="h-5 w-5 mr-2" />
                    README.md
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose dark:prose-invert max-w-none">
                  <h2>🚀 {project.name}</h2>
                  <p>
                    Welcome to {project.name}! This project is built with modern web technologies 
                    and follows best practices for scalable application development.
                  </p>
                  
                  <h3>✨ Features</h3>
                  <ul>
                    <li>Modern React with TypeScript</li>
                    <li>Responsive design with Tailwind CSS</li>
                    <li>Component-based architecture</li>
                    <li>State management with React Query</li>
                    <li>Authentication and authorization</li>
                    <li>Real-time updates</li>
                  </ul>

                  <h3>🛠️ Tech Stack</h3>
                  <ul>
                    <li><strong>Frontend:</strong> React, TypeScript, Tailwind CSS</li>
                    <li><strong>Backend:</strong> Node.js, Express</li>
                    <li><strong>Database:</strong> PostgreSQL</li>
                    <li><strong>Deployment:</strong> Vercel, Railway</li>
                  </ul>

                  <h3>📦 Installation</h3>
                  <pre><code>npm install
npm run dev</code></pre>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="h-5 w-5 mr-2" />
                    Recent Commits
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {commitActivity.slice(0, 5).map((day, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-dark-elevated">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-green-100 dark:bg-green-500/20 rounded-full flex items-center justify-center">
                          <Activity className="h-4 w-4 text-green-500" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-dark-text">
                            {day.commits} commits on {day.date}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-dark-muted">
                            Various bug fixes and improvements
                          </p>
                        </div>
                      </div>
                      <Badge variant="secondary">{day.commits}</Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              {/* Languages */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Code className="h-5 w-5 mr-2" />
                    Languages
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {Object.entries(projectStats.languages).map(([lang, percentage]) => (
                    <div key={lang} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">{lang}</span>
                        <span>{percentage}%</span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Project Health */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2" />
                    Project Health
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Code Quality</span>
                      <span className="font-medium text-green-600">{projectStats.codeQuality}%</span>
                    </div>
                    <Progress value={projectStats.codeQuality} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Test Coverage</span>
                      <span className="font-medium text-blue-600">{projectStats.testCoverage}%</span>
                    </div>
                    <Progress value={projectStats.testCoverage} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Documentation</span>
                      <span className="font-medium text-yellow-600">{projectStats.documentation}%</span>
                    </div>
                    <Progress value={projectStats.documentation} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="files" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Project Files</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {projectFiles.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-dark-elevated">
                    <div className="flex items-center space-x-3">
                      {file.type === "directory" ? (
                        <div className="w-5 h-5 text-blue-500">📁</div>
                      ) : (
                        <div className="w-5 h-5 text-gray-500">📄</div>
                      )}
                      <span className="font-medium text-gray-900 dark:text-dark-text">
                        {file.name}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600 dark:text-dark-muted">
                      {file.type === "file" ? formatBytes(file.size) : "—"}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contributors" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {contributors.map((contributor) => (
              <Card key={contributor.id}>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 mb-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={contributor.avatar} alt={contributor.username} />
                      <AvatarFallback>{contributor.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 dark:text-dark-text">
                        {contributor.username}
                      </h3>
                      <Badge className={getRoleColor(contributor.role)} >
                        {contributor.role}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-dark-muted">Commits</span>
                      <span className="font-medium">{contributor.commits}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-dark-muted">Additions</span>
                      <span className="font-medium text-green-600">+{contributor.additions}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-dark-muted">Deletions</span>
                      <span className="font-medium text-red-600">-{contributor.deletions}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="activity" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="h-5 w-5 mr-2" />
                Commit Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-4">
                {commitActivity.map((day, index) => (
                  <div key={index} className="text-center">
                    <div className="text-xs text-gray-600 dark:text-dark-muted mb-2">
                      {new Date(day.date).toLocaleDateString('en-US', { weekday: 'short' })}
                    </div>
                    <div 
                      className="w-full bg-green-100 dark:bg-green-500/20 rounded-md flex items-end justify-center"
                      style={{ height: `${Math.max(20, day.commits * 4)}px` }}
                    >
                      <div className="text-xs font-medium text-green-700 dark:text-green-300 mb-1">
                        {day.commits}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Development Trends</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Most Active Day</span>
                  <Badge>Thursday</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Peak Commit Hour</span>
                  <Badge>2:00 PM</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Average Commits/Day</span>
                  <Badge>{Math.round(projectStats.commits / 30)}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Repository Age</span>
                  <Badge>8 months</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Build Success Rate</span>
                  <Badge className="bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400">
                    98.5%
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Average Build Time</span>
                  <Badge>2m 34s</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Issues Resolution Time</span>
                  <Badge>1.2 days</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">PR Review Time</span>
                  <Badge>4.8 hours</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}