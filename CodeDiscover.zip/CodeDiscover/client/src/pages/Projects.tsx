import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github, Star, GitFork, Filter, ArrowUpDown } from "lucide-react";
import type { Project } from "@shared/schema";

function ProjectSkeleton() {
  return (
    <Card>
      <CardContent className="p-6">
        <Skeleton className="h-4 w-3/4 mb-4" />
        <Skeleton className="h-3 w-full mb-2" />
        <Skeleton className="h-3 w-2/3 mb-4" />
        <div className="flex justify-between items-center">
          <Skeleton className="h-6 w-16" />
          <Skeleton className="h-8 w-24" />
        </div>
      </CardContent>
    </Card>
  );
}

export default function Projects() {
  const [showSkeletons, setShowSkeletons] = useState(true);

  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Show skeletons for 3 seconds, then actual content
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSkeletons(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const getLanguageColor = (language: string | null) => {
    const colors: Record<string, string> = {
      JavaScript: "bg-yellow-100 text-yellow-600 dark:bg-yellow-500/20 dark:text-yellow-400",
      TypeScript: "bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400",
      React: "bg-cyan-100 text-cyan-600 dark:bg-cyan-500/20 dark:text-cyan-400",
      Python: "bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400",
      Java: "bg-red-100 text-red-600 dark:bg-red-500/20 dark:text-red-400",
      HTML: "bg-orange-100 text-orange-600 dark:bg-orange-500/20 dark:text-orange-400",
      CSS: "bg-purple-100 text-purple-600 dark:bg-purple-500/20 dark:text-purple-400",
      "C++": "bg-pink-100 text-pink-600 dark:bg-pink-500/20 dark:text-pink-400",
    };
    return colors[language || ""] || "bg-gray-100 text-gray-600 dark:bg-gray-500/20 dark:text-gray-400";
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-dark-text">
            My Projects
          </h1>
          <p className="text-gray-600 dark:text-dark-muted mt-2">
            Explore projects from Ronit-CodeWizard/CodeWizard GitHub repository
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <ArrowUpDown className="h-4 w-4 mr-2" />
            Sort
          </Button>
        </div>
      </div>

      {/* Project Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {(isLoading || showSkeletons) ? (
          // Show skeletons while loading or during initial 3 seconds
          Array.from({ length: 8 }).map((_, index) => (
            <ProjectSkeleton key={index} />
          ))
        ) : (
          projects.map((project) => (
            <Card
              key={project.id}
              className="hover:shadow-lg transition-all duration-300 cursor-pointer"
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-dark-text line-clamp-1">
                    {project.name}
                  </h3>
                  <div className="text-yellow-500 flex items-center">
                    <Star className="h-4 w-4 mr-1" />
                    <span className="text-sm">{project.stargazersCount}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-gray-600 dark:text-dark-muted text-sm mb-4 line-clamp-2">
                  {project.description || "No description available"}
                </p>
                
                <div className="flex items-center justify-between mb-4">
                  {project.language && (
                    <Badge className={getLanguageColor(project.language)}>
                      {project.language}
                    </Badge>
                  )}
                  <div className="flex items-center text-gray-500 dark:text-dark-muted text-sm">
                    <GitFork className="h-3 w-3 mr-1" />
                    <span>{project.forksCount}</span>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button
                    size="sm"
                    className="flex-1"
                    onClick={() => window.open(project.htmlUrl, "_blank")}
                  >
                    <ExternalLink className="h-3 w-3 mr-1" />
                    View Live
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(project.htmlUrl, "_blank")}
                  >
                    <Github className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {!isLoading && !showSkeletons && projects.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-500 dark:text-dark-muted mb-4">
            <Github className="h-12 w-12 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Projects Found</h3>
            <p>Unable to fetch projects from GitHub at the moment.</p>
          </div>
        </div>
      )}
    </div>
  );
}
