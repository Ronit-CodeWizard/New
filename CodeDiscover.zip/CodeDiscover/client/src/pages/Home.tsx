import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { FolderOpen, Code, Bot, Camera, Activity } from "lucide-react";

export default function Home() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-dark-muted">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect to login
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-50 to-purple-50 dark:from-dark-bg dark:to-dark-surface"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 dark:text-dark-text mb-6">
              Welcome back, <span className="text-brand-500">{user?.firstName || user?.email?.split("@")[0] || "Developer"}</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-dark-muted mb-8 max-w-3xl mx-auto">
              Ready to explore amazing projects, write code, and get AI-powered assistance for your development journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/projects">
                <Button size="lg" className="px-8 py-4 text-lg shadow-lg">
                  Explore Projects
                </Button>
              </Link>
              <Link href="/editor">
                <Button variant="outline" size="lg" className="px-8 py-4 text-lg border-2">
                  Open Editor
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-20 bg-gray-50 dark:bg-dark-surface">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-dark-text mb-4">
              Quick Actions
            </h2>
            <p className="text-gray-600 dark:text-dark-muted">
              Jump right into your development workflow
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
            <Link href="/projects">
              <Card className="cursor-pointer hover:shadow-lg transition-all duration-300 border-0 shadow-md">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-brand-100 dark:bg-brand-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <FolderOpen className="h-6 w-6 text-brand-500" />
                  </div>
                  <h3 className="font-semibold mb-2">Browse Projects</h3>
                  <p className="text-sm text-gray-600 dark:text-dark-muted">
                    Explore GitHub repositories
                  </p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/workspace">
              <Card className="cursor-pointer hover:shadow-lg transition-all duration-300 border-0 shadow-md">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Bot className="h-6 w-6 text-indigo-500" />
                  </div>
                  <h3 className="font-semibold mb-2">Workspace</h3>
                  <p className="text-sm text-gray-600 dark:text-dark-muted">
                    Manage your projects
                  </p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/dashboard">
              <Card className="cursor-pointer hover:shadow-lg transition-all duration-300 border-0 shadow-md">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-teal-100 dark:bg-teal-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Activity className="h-6 w-6 text-teal-500" />
                  </div>
                  <h3 className="font-semibold mb-2">Dashboard</h3>
                  <p className="text-sm text-gray-600 dark:text-dark-muted">
                    Analytics & insights
                  </p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/editor">
              <Card className="cursor-pointer hover:shadow-lg transition-all duration-300 border-0 shadow-md">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-green-100 dark:bg-green-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Code className="h-6 w-6 text-green-500" />
                  </div>
                  <h3 className="font-semibold mb-2">Code Editor</h3>
                  <p className="text-sm text-gray-600 dark:text-dark-muted">
                    Write and edit code
                  </p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/snapshot">
              <Card className="cursor-pointer hover:shadow-lg transition-all duration-300 border-0 shadow-md">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-purple-100 dark:bg-purple-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Camera className="h-6 w-6 text-purple-500" />
                  </div>
                  <h3 className="font-semibold mb-2">Code Snapshots</h3>
                  <p className="text-sm text-gray-600 dark:text-dark-muted">
                    Create beautiful screenshots
                  </p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/profile">
              <Card className="cursor-pointer hover:shadow-lg transition-all duration-300 border-0 shadow-md">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-orange-100 dark:bg-orange-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Bot className="h-6 w-6 text-orange-500" />
                  </div>
                  <h3 className="font-semibold mb-2">Profile Settings</h3>
                  <p className="text-sm text-gray-600 dark:text-dark-muted">
                    Manage your profile
                  </p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
