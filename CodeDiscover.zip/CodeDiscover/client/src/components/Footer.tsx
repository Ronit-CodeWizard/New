import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";
import { 
  Github, 
  Twitter, 
  Linkedin, 
  Mail, 
  Code, 
  Heart,
  ExternalLink,
  FileText,
  Shield,
  HelpCircle,
  Users,
  Zap,
  BookOpen
} from "lucide-react";

export default function Footer() {
  const { isAuthenticated, user } = useAuth();

  if (isAuthenticated) {
    return (
      <footer className="bg-gray-50 dark:bg-dark-elevated border-t mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div className="col-span-1">
              <div className="flex items-center space-x-2 mb-4">
                <Code className="h-6 w-6 text-brand-500" />
                <span className="font-bold text-lg text-gray-900 dark:text-dark-text">CodeWizard</span>
              </div>
              <p className="text-gray-600 dark:text-dark-muted mb-4">
                Your comprehensive development platform for building, collaborating, and showcasing amazing projects.
              </p>
              <div className="flex space-x-3">
                <a 
                  href="https://github.com/Ronit-CodeWizard/CodeWizard" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-dark-text transition-colors"
                >
                  <Github className="h-5 w-5" />
                </a>
                <a 
                  href="https://twitter.com/ronit_codewizard" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-dark-text transition-colors"
                >
                  <Twitter className="h-5 w-5" />
                </a>
                <a 
                  href="mailto:support@codewizard.dev" 
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-dark-text transition-colors"
                >
                  <Mail className="h-5 w-5" />
                </a>
              </div>
            </div>

            {/* Development Tools */}
            <div>
              <h3 className="font-semibold text-gray-900 dark:text-dark-text mb-4">Development Tools</h3>
              <ul className="space-y-3">
                <li>
                  <Link href="/editor" className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center">
                    <Code className="h-4 w-4 mr-2" />
                    Code Editor
                  </Link>
                </li>
                <li>
                  <Link href="/snapshot" className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center">
                    <Zap className="h-4 w-4 mr-2" />
                    Code Snapshots
                  </Link>
                </li>
                <li>
                  <Link href="/workspace" className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center">
                    <Users className="h-4 w-4 mr-2" />
                    Workspace
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard" className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center">
                    <BookOpen className="h-4 w-4 mr-2" />
                    Analytics Dashboard
                  </Link>
                </li>
              </ul>
            </div>

            {/* Resources */}
            <div>
              <h3 className="font-semibold text-gray-900 dark:text-dark-text mb-4">Resources</h3>
              <ul className="space-y-3">
                <li>
                  <a 
                    href="https://github.com/Ronit-CodeWizard/CodeWizard/blob/main/README.md" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center"
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Documentation
                  </a>
                </li>
                <li>
                  <a 
                    href="https://github.com/Ronit-CodeWizard/CodeWizard/issues" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center"
                  >
                    <HelpCircle className="h-4 w-4 mr-2" />
                    Support
                  </a>
                </li>
                <li>
                  <a 
                    href="/api/changelog" 
                    className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center"
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Changelog
                  </a>
                </li>
                <li>
                  <a 
                    href="https://github.com/Ronit-CodeWizard/CodeWizard/releases" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center"
                  >
                    <Github className="h-4 w-4 mr-2" />
                    Releases
                  </a>
                </li>
              </ul>
            </div>

            {/* Account */}
            <div>
              <h3 className="font-semibold text-gray-900 dark:text-dark-text mb-4">Account</h3>
              <ul className="space-y-3">
                <li>
                  <Link href="/profile" className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors">
                    Profile Settings
                  </Link>
                </li>
                <li>
                  <Link href="/projects" className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors">
                    My Projects
                  </Link>
                </li>
                <li>
                  <a href="/privacy" className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center">
                    <Shield className="h-4 w-4 mr-2" />
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="/api/logout" className="text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 transition-colors">
                    Sign Out
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-600 dark:text-dark-muted mb-4 md:mb-0">
              <p>Welcome back, <span className="font-medium text-gray-900 dark:text-dark-text">{user?.firstName || user?.email?.split("@")[0] || "Developer"}</span></p>
              <p className="text-sm">Last login: {new Date().toLocaleString()}</p>
            </div>
            <div className="text-gray-600 dark:text-dark-muted text-sm">
              <p className="flex items-center">
                Made with <Heart className="h-4 w-4 text-red-500 mx-1" /> by 
                <a 
                  href="https://github.com/Ronit-CodeWizard" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ml-1 text-brand-500 hover:text-brand-600 dark:text-brand-400 dark:hover:text-brand-300"
                >
                  Ronit CodeWizard
                </a>
              </p>
              <p className="text-center md:text-right mt-1">© 2024 CodeWizard. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    );
  }

  return (
    <footer className="bg-white dark:bg-dark-bg border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <Code className="h-8 w-8 text-brand-500" />
              <span className="font-bold text-2xl text-gray-900 dark:text-dark-text">CodeWizard</span>
            </div>
            <p className="text-lg text-gray-600 dark:text-dark-muted mb-6 max-w-lg">
              The ultimate development platform for creating, collaborating, and showcasing your coding projects. 
              Join thousands of developers building the future.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://github.com/Ronit-CodeWizard/CodeWizard" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-gray-900 dark:bg-dark-card text-white px-4 py-2 rounded-lg hover:bg-gray-800 dark:hover:bg-dark-elevated transition-colors flex items-center"
              >
                <Github className="h-5 w-5 mr-2" />
                View Source
              </a>
              <a 
                href="mailto:support@codewizard.dev"
                className="border border-gray-300 dark:border-dark-border text-gray-900 dark:text-dark-text px-4 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-dark-card transition-colors flex items-center"
              >
                <Mail className="h-5 w-5 mr-2" />
                Contact Us
              </a>
            </div>
          </div>

          {/* Features */}
          <div>
            <h3 className="font-bold text-gray-900 dark:text-dark-text mb-6 text-lg">Features</h3>
            <ul className="space-y-4">
              <li className="flex items-center text-gray-600 dark:text-dark-muted">
                <Code className="h-5 w-5 mr-3 text-brand-500" />
                Advanced Code Editor
              </li>
              <li className="flex items-center text-gray-600 dark:text-dark-muted">
                <Github className="h-5 w-5 mr-3 text-brand-500" />
                GitHub Integration
              </li>
              <li className="flex items-center text-gray-600 dark:text-dark-muted">
                <Users className="h-5 w-5 mr-3 text-brand-500" />
                Team Collaboration
              </li>
              <li className="flex items-center text-gray-600 dark:text-dark-muted">
                <Zap className="h-5 w-5 mr-3 text-brand-500" />
                AI-Powered Assistance
              </li>
              <li className="flex items-center text-gray-600 dark:text-dark-muted">
                <BookOpen className="h-5 w-5 mr-3 text-brand-500" />
                Project Analytics
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-bold text-gray-900 dark:text-dark-text mb-6 text-lg">Company</h3>
            <ul className="space-y-4">
              <li>
                <a href="/about" className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a 
                  href="https://github.com/Ronit-CodeWizard/CodeWizard/blob/main/README.md" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center"
                >
                  Documentation
                  <ExternalLink className="h-4 w-4 ml-1" />
                </a>
              </li>
              <li>
                <a href="/privacy" className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="/terms" className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a 
                  href="https://github.com/Ronit-CodeWizard/CodeWizard/issues" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-600 dark:text-dark-muted hover:text-brand-500 dark:hover:text-brand-400 transition-colors flex items-center"
                >
                  Support
                  <ExternalLink className="h-4 w-4 ml-1" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom section */}
        <div className="border-t mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-6 mb-4 md:mb-0">
              <a 
                href="https://github.com/Ronit-CodeWizard/CodeWizard" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-gray-600 dark:hover:text-dark-text transition-colors"
              >
                <Github className="h-6 w-6" />
              </a>
              <a 
                href="https://twitter.com/ronit_codewizard" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-gray-600 dark:hover:text-dark-text transition-colors"
              >
                <Twitter className="h-6 w-6" />
              </a>
              <a 
                href="https://linkedin.com/in/ronit-codewizard" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-gray-600 dark:hover:text-dark-text transition-colors"
              >
                <Linkedin className="h-6 w-6" />
              </a>
            </div>
            
            <div className="text-center md:text-right">
              <p className="text-gray-600 dark:text-dark-muted flex items-center justify-center md:justify-end">
                Made with <Heart className="h-4 w-4 text-red-500 mx-1" /> by 
                <a 
                  href="https://github.com/Ronit-CodeWizard" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ml-1 text-brand-500 hover:text-brand-600 dark:text-brand-400 dark:hover:text-brand-300 font-medium"
                >
                  Ronit CodeWizard
                </a>
              </p>
              <p className="text-gray-500 dark:text-dark-muted/70 text-sm mt-2">
                © 2024 CodeWizard. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}