import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Activity,
  TrendingUp,
  Code,
  GitCommit,
  Clock,
  Users,
  Star,
  Calendar,
  Zap,
  Target,
  Award,
  BookOpen,
  ChevronRight,
  Github
} from "lucide-react";
import type { Project } from "@shared/schema";

interface ActivityItem {
  id: string;
  type: "commit" | "project" | "collaboration" | "achievement";
  title: string;
  description: string;
  timestamp: Date;
  metadata?: any;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  progress: number;
  maxProgress: number;
  unlocked: boolean;
  category: "coding" | "collaboration" | "projects" | "learning";
}

const recentActivity: ActivityItem[] = [
  {
    id: "1",
    type: "commit",
    title: "Pushed 3 commits to React Dashboard",
    description: "Added user authentication and dashboard routing",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    metadata: { commits: 3, repository: "react-dashboard" }
  },
  {
    id: "2", 
    type: "project",
    title: "Created new project: AI Chat Bot",
    description: "Started building an intelligent chatbot with NLP capabilities",
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
    metadata: { language: "Python", framework: "FastAPI" }
  },
  {
    id: "3",
    type: "collaboration",
    title: "Invited 2 collaborators to E-commerce API",
    description: "Added team members to help with backend development",
    timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000),
    metadata: { collaborators: ["john.doe", "jane.smith"] }
  },
  {
    id: "4",
    type: "achievement",
    title: "Unlocked: Code Warrior",
    description: "Completed 50+ commits this month",
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
    metadata: { achievement: "code-warrior", points: 100 }
  }
];

const achievements: Achievement[] = [
  {
    id: "1",
    title: "First Steps",
    description: "Create your first project",
    icon: "🚀",
    progress: 1,
    maxProgress: 1,
    unlocked: true,
    category: "projects"
  },
  {
    id: "2", 
    title: "Code Warrior",
    description: "Make 50 commits in a month",
    icon: "⚔️",
    progress: 52,
    maxProgress: 50,
    unlocked: true,
    category: "coding"
  },
  {
    id: "3",
    title: "Team Builder",
    description: "Collaborate on 5 projects",
    icon: "👥",
    progress: 3,
    maxProgress: 5,
    unlocked: false,
    category: "collaboration"
  },
  {
    id: "4",
    title: "Language Master",
    description: "Use 10 different programming languages",
    icon: "🎯",
    progress: 7,
    maxProgress: 10,
    unlocked: false,
    category: "learning"
  },
  {
    id: "5",
    title: "Star Collector",
    description: "Receive 100 stars across projects",
    icon: "⭐",
    progress: 23,
    maxProgress: 100,
    unlocked: false,
    category: "projects"
  },
  {
    id: "6",
    title: "Marathon Coder",
    description: "Code for 24 hours in a week",
    icon: "🏃",
    progress: 18,
    maxProgress: 24,
    unlocked: false,
    category: "coding"
  }
];

const skillsData = [
  { skill: "JavaScript", level: 92, projects: 12 },
  { skill: "TypeScript", level: 88, projects: 8 },
  { skill: "React", level: 94, projects: 10 },
  { skill: "Node.js", level: 85, projects: 6 },
  { skill: "Python", level: 78, projects: 4 },
  { skill: "Docker", level: 65, projects: 3 },
  { skill: "MongoDB", level: 72, projects: 5 },
  { skill: "PostgreSQL", level: 80, projects: 7 }
];

export default function Dashboard() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    enabled: isAuthenticated,
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "commit": return <GitCommit className="h-4 w-4" />;
      case "project": return <Code className="h-4 w-4" />;
      case "collaboration": return <Users className="h-4 w-4" />;
      case "achievement": return <Award className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case "commit": return "text-green-500";
      case "project": return "text-blue-500";
      case "collaboration": return "text-purple-500";
      case "achievement": return "text-yellow-500";
      default: return "text-gray-500";
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
    if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    return 'Just now';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-dark-muted">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Welcome Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-dark-text mb-2">
              Welcome back, {user?.firstName || user?.email?.split("@")[0] || "Developer"}!
            </h1>
            <p className="text-gray-600 dark:text-dark-muted">
              Here's what's happening with your projects and coding journey
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              This Week
            </Button>
            <Button>
              <Target className="h-4 w-4 mr-2" />
              Set Goals
            </Button>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="border-l-4 border-l-brand-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-dark-muted">Total Projects</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-dark-text">{projects.length}</p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                  <TrendingUp className="h-3 w-3 inline mr-1" />
                  +2 this month
                </p>
              </div>
              <div className="w-12 h-12 bg-brand-100 dark:bg-brand-500/20 rounded-full flex items-center justify-center">
                <Code className="h-6 w-6 text-brand-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-dark-muted">Commits This Week</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-dark-text">127</p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                  <TrendingUp className="h-3 w-3 inline mr-1" />
                  +23% from last week
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 dark:bg-green-500/20 rounded-full flex items-center justify-center">
                <GitCommit className="h-6 w-6 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-dark-muted">Hours Coded</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-dark-text">42</p>
                <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">
                  <Clock className="h-3 w-3 inline mr-1" />
                  This week
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-500/20 rounded-full flex items-center justify-center">
                <Clock className="h-6 w-6 text-purple-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-yellow-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-dark-muted">GitHub Stars</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-dark-text">
                  {projects.reduce((sum, p) => sum + (p.stargazersCount || 0), 0)}
                </p>
                <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">
                  <Star className="h-3 w-3 inline mr-1" />
                  Across all repos
                </p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-500/20 rounded-full flex items-center justify-center">
                <Star className="h-6 w-6 text-yellow-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="skills">Skills</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Projects */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Github className="h-5 w-5 mr-2" />
                  Recent Projects
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {projects.slice(0, 4).map((project) => (
                  <div key={project.id} className="flex items-center space-x-4 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-dark-elevated transition-colors">
                    <div className="w-10 h-10 bg-brand-100 dark:bg-brand-500/20 rounded-lg flex items-center justify-center">
                      <Code className="h-5 w-5 text-brand-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900 dark:text-dark-text truncate">
                        {project.name}
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-dark-muted truncate">
                        {project.description || "No description"}
                      </p>
                      <div className="flex items-center space-x-4 mt-1">
                        <span className="text-xs text-gray-500">{project.language}</span>
                        <span className="text-xs text-gray-500 flex items-center">
                          <Star className="h-3 w-3 mr-1" />
                          {project.stargazersCount}
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-gray-400" />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2" />
                  Coding Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Daily Goal</span>
                    <span className="text-sm text-gray-600 dark:text-dark-muted">6/8 hours</span>
                  </div>
                  <Progress value={75} className="h-2" />
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Weekly Goal</span>
                    <span className="text-sm text-gray-600 dark:text-dark-muted">42/50 hours</span>
                  </div>
                  <Progress value={84} className="h-2" />
                </div>

                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">98%</p>
                    <p className="text-xs text-gray-600 dark:text-dark-muted">Code Quality</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-600">12</p>
                    <p className="text-xs text-gray-600 dark:text-dark-muted">Active Repos</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="activity" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {recentActivity.map((item) => (
                <div key={item.id} className="flex items-start space-x-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getActivityColor(item.type)} bg-gray-100 dark:bg-dark-elevated`}>
                    {getActivityIcon(item.type)}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 dark:text-dark-text">
                      {item.title}
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-dark-muted mb-2">
                      {item.description}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatTimeAgo(item.timestamp)}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="skills" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BookOpen className="h-5 w-5 mr-2" />
                Skills & Technologies
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {skillsData.map((skill) => (
                <div key={skill.skill} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-900 dark:text-dark-text">
                      {skill.skill}
                    </span>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-gray-600 dark:text-dark-muted">
                        {skill.projects} projects
                      </span>
                      <span className="text-sm font-medium">
                        {skill.level}%
                      </span>
                    </div>
                  </div>
                  <Progress value={skill.level} className="h-2" />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {achievements.map((achievement) => (
              <Card key={achievement.id} className={`${achievement.unlocked ? 'border-green-200 dark:border-green-800' : ''}`}>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="text-3xl">{achievement.icon}</div>
                    <div className="flex-1">
                      <h3 className={`font-semibold ${achievement.unlocked ? 'text-green-600 dark:text-green-400' : 'text-gray-900 dark:text-dark-text'}`}>
                        {achievement.title}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-dark-muted">
                        {achievement.description}
                      </p>
                    </div>
                    {achievement.unlocked && (
                      <Badge className="bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400">
                        Unlocked
                      </Badge>
                    )}
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>{achievement.progress}/{achievement.maxProgress}</span>
                      <span>{Math.round((achievement.progress / achievement.maxProgress) * 100)}%</span>
                    </div>
                    <Progress 
                      value={(achievement.progress / achievement.maxProgress) * 100} 
                      className="h-2"
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}