import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Terminal, 
  FileText, 
  Zap, 
  Users, 
  GitBranch,
  Clock,
  Star,
  Code2,
  Play,
  Settings,
  Share
} from "lucide-react";

interface WorkspaceProject {
  id: string;
  name: string;
  description: string;
  status: "active" | "completed" | "draft";
  lastModified: Date;
  collaborators: number;
  language: string;
}

const sampleProjects: WorkspaceProject[] = [
  {
    id: "1",
    name: "React Dashboard",
    description: "Modern admin dashboard with analytics and real-time data",
    status: "active",
    lastModified: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    collaborators: 3,
    language: "TypeScript"
  },
  {
    id: "2",
    name: "AI Chat Bot",
    description: "Intelligent chatbot with natural language processing",
    status: "active",
    lastModified: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
    collaborators: 2,
    language: "Python"
  },
  {
    id: "3",
    name: "E-commerce API",
    description: "RESTful API for online store with payment integration",
    status: "completed",
    lastModified: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
    collaborators: 1,
    language: "Node.js"
  },
  {
    id: "4",
    name: "Mobile Game",
    description: "2D puzzle game with physics engine",
    status: "draft",
    lastModified: new Date(Date.now() - 72 * 60 * 60 * 1000), // 3 days ago
    collaborators: 4,
    language: "JavaScript"
  }
];

export default function Workspace() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [projects, setProjects] = useState<WorkspaceProject[]>(sampleProjects);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTab, setSelectedTab] = useState("all");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (selectedTab === "all") return matchesSearch;
    return matchesSearch && project.status === selectedTab;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400";
      case "completed":
        return "bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400";
      case "draft":
        return "bg-gray-100 text-gray-600 dark:bg-gray-500/20 dark:text-gray-400";
      default:
        return "bg-gray-100 text-gray-600 dark:bg-gray-500/20 dark:text-gray-400";
    }
  };

  const getLanguageColor = (language: string) => {
    const colors: Record<string, string> = {
      JavaScript: "bg-yellow-100 text-yellow-600 dark:bg-yellow-500/20 dark:text-yellow-400",
      TypeScript: "bg-blue-100 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400",
      Python: "bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400",
      "Node.js": "bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400",
    };
    return colors[language] || "bg-gray-100 text-gray-600 dark:bg-gray-500/20 dark:text-gray-400";
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);

    if (days > 0) {
      return `${days} day${days > 1 ? 's' : ''} ago`;
    }
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-dark-muted">Loading workspace...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect to login
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
        <div className="mb-4 lg:mb-0">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-dark-text mb-2">
            Your Workspace
          </h1>
          <p className="text-gray-600 dark:text-dark-muted">
            Manage your projects, collaborate with teammates, and track progress
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <Button>
            <FileText className="h-4 w-4 mr-2" />
            New Project
          </Button>
          <Button variant="outline">
            <Share className="h-4 w-4 mr-2" />
            Invite Team
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-brand-100 dark:bg-brand-500/20 rounded-xl flex items-center justify-center mr-4">
                <Code2 className="h-6 w-6 text-brand-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">{projects.length}</p>
                <p className="text-sm text-gray-600 dark:text-dark-muted">Total Projects</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-500/20 rounded-xl flex items-center justify-center mr-4">
                <Play className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">
                  {projects.filter(p => p.status === "active").length}
                </p>
                <p className="text-sm text-gray-600 dark:text-dark-muted">Active</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-500/20 rounded-xl flex items-center justify-center mr-4">
                <Users className="h-6 w-6 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">
                  {projects.reduce((sum, p) => sum + p.collaborators, 0)}
                </p>
                <p className="text-sm text-gray-600 dark:text-dark-muted">Collaborators</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-500/20 rounded-xl flex items-center justify-center mr-4">
                <Terminal className="h-6 w-6 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">24</p>
                <p className="text-sm text-gray-600 dark:text-dark-muted">Hours Coded</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col lg:flex-row lg:items-center gap-4 mb-6">
        <div className="flex-1">
          <Input
            placeholder="Search projects..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-md"
          />
        </div>
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
            <TabsTrigger value="draft">Draft</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredProjects.map((project) => (
          <Card key={project.id} className="hover:shadow-lg transition-all duration-300 cursor-pointer">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg font-semibold text-gray-900 dark:text-dark-text mb-2">
                    {project.name}
                  </CardTitle>
                  <p className="text-sm text-gray-600 dark:text-dark-muted line-clamp-2 mb-3">
                    {project.description}
                  </p>
                </div>
                <Button variant="ghost" size="icon" className="flex-shrink-0">
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge className={getStatusColor(project.status)}>
                  {project.status}
                </Badge>
                <Badge className={getLanguageColor(project.language)}>
                  {project.language}
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="pt-0">
              <div className="flex items-center justify-between text-sm text-gray-600 dark:text-dark-muted mb-4">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>{formatTimeAgo(project.lastModified)}</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-4 w-4 mr-1" />
                  <span>{project.collaborators}</span>
                </div>
              </div>

              <div className="flex space-x-2">
                <Button size="sm" className="flex-1">
                  <Play className="h-3 w-3 mr-1" />
                  Open
                </Button>
                <Button variant="outline" size="sm">
                  <GitBranch className="h-3 w-3 mr-1" />
                  Fork
                </Button>
                <Button variant="outline" size="sm">
                  <Star className="h-3 w-3" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredProjects.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-500 dark:text-dark-muted mb-4">
            <FileText className="h-12 w-12 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Projects Found</h3>
            <p>
              {searchTerm 
                ? `No projects match "${searchTerm}"`
                : "Start by creating your first project"
              }
            </p>
          </div>
          <Button>
            <FileText className="h-4 w-4 mr-2" />
            Create New Project
          </Button>
        </div>
      )}
    </div>
  );
}