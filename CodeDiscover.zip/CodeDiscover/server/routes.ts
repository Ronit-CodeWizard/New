import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { generateAIResponse, explainCode } from "./openai";
import { executeCode } from "./codeExecution";
import { insertUserSchema, insertCodeSnapshotSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User profile routes
  app.patch('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const updateData = insertUserSchema.partial().parse(req.body);
      
      const updatedUser = await storage.updateUser(userId, updateData);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // GitHub projects routes
  app.get('/api/projects', async (req, res) => {
    try {
      // Check cache first
      let projects = await storage.getProjects();
      
      // If cache is empty or old, fetch files from CodeWizard repository
      if (projects.length === 0) {
        const githubUsername = 'Ronit-CodeWizard';
        const repoName = 'CodeWizard';
        
        // First get the repository info
        const repoResponse = await fetch(`https://api.github.com/repos/${githubUsername}/${repoName}`);
        
        if (repoResponse.ok) {
          const repoData = await repoResponse.json();
          
          // Get repository contents (files and folders)
          const contentsResponse = await fetch(`https://api.github.com/repos/${githubUsername}/${repoName}/contents`);
          
          if (contentsResponse.ok) {
            const contents = await contentsResponse.json();
            
            // Process each file/folder as a project
            for (const item of contents) {
              if (item.type === 'file') {
                // Determine language from file extension
                const extension = item.name.split('.').pop()?.toLowerCase();
                const languageMap: { [key: string]: string } = {
                  'js': 'JavaScript',
                  'jsx': 'JavaScript',
                  'ts': 'TypeScript', 
                  'tsx': 'TypeScript',
                  'py': 'Python',
                  'html': 'HTML',
                  'css': 'CSS',
                  'json': 'JSON',
                  'md': 'Markdown',
                  'txt': 'Text',
                  'yml': 'YAML',
                  'yaml': 'YAML'
                };
                
                await storage.upsertProject({
                  githubId: item.sha ? parseInt(item.sha.slice(0, 8), 16) : Math.floor(Math.random() * 1000000),
                  name: item.name,
                  description: `File from CodeWizard repository: ${item.name}`,
                  htmlUrl: item.html_url,
                  cloneUrl: item.download_url || item.html_url,
                  language: languageMap[extension || ''] || 'Other',
                  stargazersCount: repoData.stargazers_count,
                  forksCount: repoData.forks_count,
                  isPublic: repoData.private ? "false" : "true",
                });
              } else if (item.type === 'dir') {
                // For directories, create a project entry
                await storage.upsertProject({
                  githubId: item.name.length * 1000 + Math.floor(Math.random() * 1000),
                  name: `📁 ${item.name}`,
                  description: `Directory from CodeWizard repository: ${item.name}`,
                  htmlUrl: item.html_url,
                  cloneUrl: item.url,
                  language: 'Folder',
                  stargazersCount: repoData.stargazers_count,
                  forksCount: repoData.forks_count,
                  isPublic: repoData.private ? "false" : "true",
                });
              }
            }
          }
          
          // Get updated projects from cache
          projects = await storage.getProjects();
        }
      }
      
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get('/api/projects/language/:language', async (req, res) => {
    try {
      const { language } = req.params;
      const projects = await storage.getProjectsByLanguage(language);
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects by language:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  // Code execution endpoint
  app.post('/api/execute', async (req, res) => {
    try {
      const { code, language, filename } = req.body;
      
      if (!code || !language) {
        return res.status(400).json({ error: 'Code and language are required' });
      }

      const result = await executeCode(code, language, filename);
      res.json(result);
    } catch (error) {
      console.error("Error executing code:", error);
      res.status(500).json({ error: "Failed to execute code" });
    }
  });

  // Code snapshot routes
  app.get('/api/snapshots', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const snapshots = await storage.getCodeSnapshots(userId);
      res.json(snapshots);
    } catch (error) {
      console.error("Error fetching snapshots:", error);
      res.status(500).json({ message: "Failed to fetch snapshots" });
    }
  });

  app.post('/api/snapshots', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const snapshotData = insertCodeSnapshotSchema.parse({
        ...req.body,
        userId,
      });
      
      const snapshot = await storage.createCodeSnapshot(snapshotData);
      res.status(201).json(snapshot);
    } catch (error) {
      console.error("Error creating snapshot:", error);
      res.status(500).json({ message: "Failed to create snapshot" });
    }
  });

  app.get('/api/snapshots/:id', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const snapshot = await storage.getCodeSnapshot(id);
      
      if (!snapshot) {
        return res.status(404).json({ message: "Snapshot not found" });
      }
      
      res.json(snapshot);
    } catch (error) {
      console.error("Error fetching snapshot:", error);
      res.status(500).json({ message: "Failed to fetch snapshot" });
    }
  });

  // AI assistant routes
  app.post('/api/ai/chat', isAuthenticated, async (req, res) => {
    try {
      const { message, context } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }
      
      const response = await generateAIResponse(message, context);
      res.json({ response });
    } catch (error) {
      console.error("Error generating AI response:", error);
      res.status(500).json({ message: "Failed to generate AI response" });
    }
  });

  app.post('/api/ai/explain', isAuthenticated, async (req, res) => {
    try {
      const { code, language } = req.body;
      
      if (!code || !language) {
        return res.status(400).json({ message: "Code and language are required" });
      }
      
      const explanation = await explainCode(code, language);
      res.json({ explanation });
    } catch (error) {
      console.error("Error explaining code:", error);
      res.status(500).json({ message: "Failed to explain code" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
