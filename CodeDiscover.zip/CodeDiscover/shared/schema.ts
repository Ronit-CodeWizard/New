import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  githubUsername: varchar("github_username"),
  bio: text("bio"),
  location: varchar("location"),
  skills: text("skills").array(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Projects table for caching GitHub projects
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  githubId: integer("github_id").unique(),
  name: varchar("name").notNull(),
  description: text("description"),
  htmlUrl: varchar("html_url").notNull(),
  cloneUrl: varchar("clone_url").notNull(),
  language: varchar("language"),
  stargazersCount: integer("stargazers_count").default(0),
  forksCount: integer("forks_count").default(0),
  isPublic: varchar("is_public").default("true"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Code snapshots table
export const codeSnapshots = pgTable("code_snapshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  title: varchar("title"),
  language: varchar("language").notNull(),
  theme: varchar("theme").notNull(),
  code: text("code").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;
export type Project = typeof projects.$inferSelect;
export type InsertCodeSnapshot = typeof codeSnapshots.$inferInsert;
export type CodeSnapshot = typeof codeSnapshots.$inferSelect;

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  firstName: true,
  lastName: true,
  profileImageUrl: true,
  githubUsername: true,
  bio: true,
  location: true,
  skills: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  updatedAt: true,
});

export const insertCodeSnapshotSchema = createInsertSchema(codeSnapshots).omit({
  id: true,
  createdAt: true,
});

export type InsertUserData = z.infer<typeof insertUserSchema>;
export type InsertProjectData = z.infer<typeof insertProjectSchema>;
export type InsertCodeSnapshotData = z.infer<typeof insertCodeSnapshotSchema>;
