import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { 
  Play, 
  Save, 
  Download, 
  Upload, 
  FileText, 
  Code, 
  Settings,
  Palette,
  Monitor,
  Zap,
  Users,
  GitBranch,
  Terminal,
  Eye,
  Search,
  Replace,
  BookOpen,
  History,
  Share2,
  Folder,
  Plus,
  X,
  MoreHorizontal,
  Copy,
  Scissors,
  RotateCcw,
  RotateCw
} from "lucide-react";

interface FileTab {
  id: string;
  name: string;
  content: string;
  language: string;
  modified: boolean;
  path: string;
}

interface EditorSettings {
  theme: "light" | "dark" | "monokai" | "github";
  fontSize: number;
  tabSize: number;
  lineNumbers: boolean;
  minimap: boolean;
  wordWrap: boolean;
  autoSave: boolean;
}

const sampleFiles: FileTab[] = [
  {
    id: "1",
    name: "App.tsx",
    language: "typescript",
    path: "/src/App.tsx",
    modified: false,
    content: `import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { ThemeProvider } from '@/components/theme-provider';
import Header from '@/components/Header';
import Home from '@/pages/Home';
import Projects from '@/pages/Projects';
import './App.css';

const queryClient = new QueryClient();

function App() {
  const [user, setUser] = useState(null);
  
  useEffect(() => {
    // Initialize user authentication
    fetchUser();
  }, []);

  const fetchUser = async () => {
    try {
      const response = await fetch('/api/auth/user');
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      }
    } catch (error) {
      console.error('Failed to fetch user:', error);
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="system" storageKey="codewizard-theme">
        <Router>
          <div className="min-h-screen bg-background">
            <Header user={user} />
            <main className="container mx-auto px-4 py-8">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/projects" element={<Projects />} />
              </Routes>
            </main>
            <Toaster />
          </div>
        </Router>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;`
  },
  {
    id: "2",
    name: "components/Header.tsx",
    language: "typescript",
    path: "/src/components/Header.tsx",
    modified: true,
    content: `import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Moon, 
  Sun, 
  User, 
  Settings, 
  LogOut, 
  Code,
  GitBranch
} from 'lucide-react';

interface HeaderProps {
  user: any;
}

const Header: React.FC<HeaderProps> = ({ user }) => {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center space-x-6">
          <Link to="/" className="flex items-center space-x-2">
            <Code className="h-6 w-6 text-primary" />
            <span className="font-bold text-lg">CodeWizard</span>
          </Link>
          
          <nav className="hidden md:flex items-center space-x-6">
            <Link 
              to="/" 
              className={\`text-sm font-medium transition-colors hover:text-primary \${
                isActive('/') ? 'text-primary' : 'text-muted-foreground'
              }\`}
            >
              Home
            </Link>
            <Link 
              to="/projects" 
              className={\`text-sm font-medium transition-colors hover:text-primary \${
                isActive('/projects') ? 'text-primary' : 'text-muted-foreground'
              }\`}
            >
              Projects
            </Link>
          </nav>
        </div>

        <div className="flex items-center space-x-4">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.profileImageUrl} alt={user.email} />
                    <AvatarFallback>
                      {user.email?.[0]?.toUpperCase() || 'U'}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuItem asChild>
                  <Link to="/profile">
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/settings">
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => window.location.href = '/api/logout'}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button onClick={() => window.location.href = '/api/login'}>
              Sign In
            </Button>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;`
  },
  {
    id: "3",
    name: "utils/api.ts",
    language: "typescript", 
    path: "/src/utils/api.ts",
    modified: false,
    content: `import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      cacheTime: 1000 * 60 * 30, // 30 minutes
      retry: (failureCount, error: any) => {
        if (error?.status === 404) return false;
        return failureCount < 2;
      },
    },
  },
});

export async function apiRequest(url: string, options: RequestInit = {}) {
  const config: RequestInit = {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  };

  const response = await fetch(url, config);
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(\`\${response.status}: \${error}\`);
  }
  
  return response.json();
}

export const api = {
  get: (url: string) => apiRequest(url),
  post: (url: string, data: any) => 
    apiRequest(url, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  put: (url: string, data: any) =>
    apiRequest(url, {
      method: 'PUT', 
      body: JSON.stringify(data),
    }),
  delete: (url: string) =>
    apiRequest(url, { method: 'DELETE' }),
};`
  },
  {
    id: "4",
    name: "styles/globals.css",
    language: "css",
    path: "/src/styles/globals.css",
    modified: false,
    content: `@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 222.2 84% 4.9%;
    
    --card: 0 0% 100%;
    --card-foreground: 222.2 84% 4.9%;
    
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 84% 4.9%;
    
    --primary: 221.2 83.2% 53.3%;
    --primary-foreground: 210 40% 98%;
    
    --secondary: 210 40% 96%;
    --secondary-foreground: 222.2 84% 4.9%;
    
    --muted: 210 40% 96%;
    --muted-foreground: 215.4 16.3% 46.9%;
    
    --accent: 210 40% 96%;
    --accent-foreground: 222.2 84% 4.9%;
    
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 210 40% 98%;
    
    --border: 214.3 31.8% 91.4%;
    --input: 214.3 31.8% 91.4%;
    --ring: 221.2 83.2% 53.3%;
    
    --radius: 0.5rem;
  }
  
  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    
    --primary: 217.2 91.2% 59.8%;
    --primary-foreground: 222.2 84% 4.9%;
    
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 224.3 76.3% 94.0%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  
  body {
    @apply bg-background text-foreground;
    font-feature-settings: "rlig" 1, "calt" 1;
  }
  
  /* Code editor specific styles */
  .editor-container {
    @apply font-mono text-sm;
  }
  
  .line-numbers {
    @apply select-none text-muted-foreground text-right pr-4;
    width: 60px;
  }
  
  .code-line {
    @apply min-h-[1.5rem] px-2;
  }
  
  .code-line:hover {
    @apply bg-muted/50;
  }
}

/* Syntax highlighting */
.token.comment {
  @apply text-green-600 dark:text-green-400 italic;
}

.token.keyword {
  @apply text-blue-600 dark:text-blue-400 font-semibold;
}

.token.string {
  @apply text-orange-600 dark:text-orange-400;
}

.token.number {
  @apply text-purple-600 dark:text-purple-400;
}

.token.function {
  @apply text-red-600 dark:text-red-400;
}

.token.variable {
  @apply text-gray-800 dark:text-gray-200;
}`
  }
];

const languages = [
  "javascript",
  "typescript", 
  "python",
  "java",
  "cpp",
  "html",
  "css",
  "json",
  "markdown"
];

const editorThemes = [
  { value: "light", label: "Light" },
  { value: "dark", label: "Dark" },
  { value: "monokai", label: "Monokai" },
  { value: "github", label: "GitHub" }
];

export default function Editor() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [files, setFiles] = useState<FileTab[]>(sampleFiles);
  const [activeFileId, setActiveFileId] = useState(files[0]?.id || "");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [settings, setSettings] = useState<EditorSettings>({
    theme: "dark",
    fontSize: 14,
    tabSize: 2,
    lineNumbers: true,
    minimap: true,
    wordWrap: false,
    autoSave: true
  });
  const [showCollaborators, setShowCollaborators] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [output, setOutput] = useState("Welcome to CodeWizard Editor! Click 'Run' to execute your code.\n");
  const [isExecuting, setIsExecuting] = useState(false);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const activeFile = files.find(f => f.id === activeFileId);

  const createNewFile = () => {
    const newFile: FileTab = {
      id: Date.now().toString(),
      name: "untitled.js",
      content: "// New file\n",
      language: "javascript",
      modified: false,
      path: "/untitled.js"
    };
    setFiles([...files, newFile]);
    setActiveFileId(newFile.id);
  };

  const closeFile = (fileId: string) => {
    const newFiles = files.filter(f => f.id !== fileId);
    setFiles(newFiles);
    if (activeFileId === fileId && newFiles.length > 0) {
      setActiveFileId(newFiles[0].id);
    }
  };

  const updateFileContent = (fileId: string, content: string) => {
    setFiles(files.map(f => 
      f.id === fileId 
        ? { ...f, content, modified: true }
        : f
    ));
  };

  const saveFile = (fileId: string) => {
    setFiles(files.map(f => 
      f.id === fileId 
        ? { ...f, modified: false }
        : f
    ));
    toast({
      title: "File saved",
      description: `${files.find(f => f.id === fileId)?.name} has been saved.`,
    });
  };

  const runCode = async () => {
    if (!activeFile) return;
    
    setOutput("Running code...\n");
    setIsExecuting(true);
    
    toast({
      title: "Running code...",
      description: `Executing ${activeFile.name}`,
    });
    
    try {
      const response = await fetch('/api/execute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          code: activeFile.content,
          language: activeFile.language,
          filename: activeFile.name,
        }),
      });

      const result = await response.json();
      
      if (response.ok) {
        setOutput(result.output || "Code executed successfully with no output.");
        toast({
          title: "Code executed successfully",
          description: "Check the output in the console below.",
        });
      } else {
        setOutput(`Error: ${result.error || 'Execution failed'}`);
        toast({
          title: "Execution failed",
          description: result.error || "An error occurred during execution.",
          variant: "destructive",
        });
      }
    } catch (error) {
      setOutput(`Error: ${error instanceof Error ? error.message : 'Network error'}`);
      toast({
        title: "Execution failed",
        description: "Failed to execute code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExecuting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-dark-muted">Loading editor...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="h-screen flex flex-col">
      {/* Editor Toolbar */}
      <div className="flex items-center justify-between p-4 border-b bg-gray-50 dark:bg-dark-elevated">
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="sm" onClick={createNewFile}>
            <Plus className="h-4 w-4 mr-2" />
            New File
          </Button>
          <Button variant="outline" size="sm" onClick={() => saveFile(activeFileId)}>
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
          <Button variant="default" size="sm" onClick={runCode} disabled={isExecuting}>
            <Play className="h-4 w-4 mr-2" />
            {isExecuting ? 'Running...' : 'Run'}
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button variant="ghost" size="sm" onClick={() => setShowFindReplace(!showFindReplace)}>
            <Search className="h-4 w-4 mr-2" />
            Find
          </Button>
          <Button variant="ghost" size="sm">
            <GitBranch className="h-4 w-4 mr-2" />
            Git
          </Button>
        </div>

        <div className="flex items-center space-x-2">
          <Badge variant="secondary" className="text-xs">
            {activeFile?.language || "text"}
          </Badge>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setShowCollaborators(!showCollaborators)}
          >
            <Users className="h-4 w-4 mr-2" />
            {showCollaborators ? "Hide" : "Show"} Collaborators
          </Button>
          <Button variant="ghost" size="sm">
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Find/Replace Bar */}
      {showFindReplace && (
        <div className="flex items-center space-x-4 p-3 border-b bg-yellow-50 dark:bg-yellow-900/20">
          <Input
            placeholder="Find..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-64"
          />
          <Input
            placeholder="Replace with..."
            className="w-64"
          />
          <Button size="sm">Replace</Button>
          <Button size="sm" variant="outline">Replace All</Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setShowFindReplace(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        {!sidebarCollapsed && (
          <div className="w-64 border-r bg-gray-50 dark:bg-dark-elevated">
            <Tabs defaultValue="files" className="h-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="files">Files</TabsTrigger>
                <TabsTrigger value="search">Search</TabsTrigger>
                <TabsTrigger value="git">Git</TabsTrigger>
              </TabsList>
              
              <TabsContent value="files" className="p-4 space-y-2">
                <h3 className="font-semibold text-sm mb-3">Project Files</h3>
                {files.map((file) => (
                  <div
                    key={file.id}
                    className={`flex items-center justify-between p-2 rounded cursor-pointer hover:bg-white dark:hover:bg-dark-card ${
                      file.id === activeFileId ? 'bg-white dark:bg-dark-card shadow-sm' : ''
                    }`}
                    onClick={() => setActiveFileId(file.id)}
                  >
                    <div className="flex items-center space-x-2">
                      <FileText className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">{file.name}</span>
                      {file.modified && (
                        <div className="w-2 h-2 bg-orange-400 rounded-full" />
                      )}
                    </div>
                  </div>
                ))}
              </TabsContent>

              <TabsContent value="search" className="p-4">
                <div className="space-y-4">
                  <Input placeholder="Search in files..." />
                  <div className="text-sm text-gray-600 dark:text-dark-muted">
                    No search results
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="git" className="p-4">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <GitBranch className="h-4 w-4" />
                    <span className="text-sm font-medium">main</span>
                  </div>
                  <div className="text-sm text-gray-600 dark:text-dark-muted">
                    No changes to commit
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}

        {/* Main Editor Area */}
        <div className="flex-1 flex flex-col">
          {/* File Tabs */}
          <div className="flex items-center border-b bg-white dark:bg-dark-card">
            {files.map((file) => (
              <div
                key={file.id}
                className={`flex items-center space-x-2 px-4 py-2 border-r cursor-pointer hover:bg-gray-50 dark:hover:bg-dark-elevated ${
                  file.id === activeFileId ? 'bg-gray-50 dark:bg-dark-elevated border-b-2 border-b-brand-500' : ''
                }`}
                onClick={() => setActiveFileId(file.id)}
              >
                <FileText className="h-4 w-4 text-gray-400" />
                <span className="text-sm">{file.name}</span>
                {file.modified && (
                  <div className="w-2 h-2 bg-orange-400 rounded-full" />
                )}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    closeFile(file.id);
                  }}
                  className="ml-2 hover:bg-gray-200 dark:hover:bg-dark-card rounded p-0.5"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>

          {/* Editor Content */}
          <div className="flex-1 flex">
            <div className="flex-1 relative">
              {activeFile ? (
                <div className="h-full">
                  <div className="flex h-full">
                    {/* Line Numbers */}
                    {settings.lineNumbers && (
                      <div className="line-numbers bg-gray-50 dark:bg-dark-elevated border-r px-2 py-4">
                        {activeFile.content.split('\n').map((_, index) => (
                          <div key={index} className="text-xs leading-6">
                            {index + 1}
                          </div>
                        ))}
                      </div>
                    )}
                    
                    {/* Code Editor */}
                    <div className="flex-1">
                      <Textarea
                        value={activeFile.content}
                        onChange={(e) => updateFileContent(activeFile.id, e.target.value)}
                        className="w-full h-full resize-none border-0 rounded-none editor-container"
                        style={{ 
                          fontSize: `${settings.fontSize}px`,
                          fontFamily: 'Monaco, "Cascadia Code", "Roboto Mono", Consolas, "Courier New", monospace'
                        }}
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-gray-500">
                  <div className="text-center">
                    <Code className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No file selected</p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={createNewFile}
                    >
                      Create New File
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Collaborators Panel */}
            {showCollaborators && (
              <div className="w-80 border-l bg-white dark:bg-dark-card p-4">
                <h3 className="font-semibold mb-4">Collaborators</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-100 dark:bg-green-500/20 rounded-full flex items-center justify-center">
                      <span className="text-xs font-medium text-green-600">RC</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Ronit (You)</p>
                      <p className="text-xs text-gray-500">Owner • Online</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 dark:bg-blue-500/20 rounded-full flex items-center justify-center">
                      <span className="text-xs font-medium text-blue-600">JS</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Jane Smith</p>
                      <p className="text-xs text-gray-500">Editor • Online</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-100 dark:bg-gray-500/20 rounded-full flex items-center justify-center">
                      <span className="text-xs font-medium text-gray-600">AD</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Alex Dev</p>
                      <p className="text-xs text-gray-500">Viewer • Offline</p>
                    </div>
                  </div>
                </div>

                <Button variant="outline" className="w-full mt-4">
                  <Share2 className="h-4 w-4 mr-2" />
                  Share Project
                </Button>
              </div>
            )}
          </div>

          {/* Output Panel */}
          <div className="h-48 border-t bg-black text-green-400 font-mono text-sm">
            <Tabs defaultValue="console" className="h-full">
              <div className="border-b bg-gray-900 px-2">
                <TabsList className="bg-transparent border-0">
                  <TabsTrigger value="console" className="text-white">Console</TabsTrigger>
                  <TabsTrigger value="terminal" className="text-white">Terminal</TabsTrigger>
                  <TabsTrigger value="output" className="text-white">Output</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="console" className="p-4 h-full overflow-auto">
                <div className="space-y-1">
                  <div>$ npm start</div>
                  <div className="text-yellow-400">Starting development server...</div>
                  <div className="text-green-400">✓ Server running on http://localhost:3000</div>
                  <div className="text-blue-400">Ready for hot reload</div>
                </div>
              </TabsContent>

              <TabsContent value="terminal" className="p-4 h-full overflow-auto">
                <div>
                  <span className="text-blue-400">user@codewizard</span>
                  <span className="text-white">:</span>
                  <span className="text-green-400">~/project</span>
                  <span className="text-white">$ </span>
                  <span className="animate-pulse">|</span>
                </div>
              </TabsContent>

              <TabsContent value="output" className="p-4 h-full overflow-auto">
                <div className={`whitespace-pre-wrap ${output.includes('Error:') ? 'text-red-400' : 'text-green-400'}`}>
                  {output}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}