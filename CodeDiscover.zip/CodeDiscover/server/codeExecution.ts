import { exec } from "child_process";
import { promisify } from "util";
import { writeFileSync, mkdirSync, existsSync, unlinkSync } from "fs";
import { join } from "path";
import OpenAI from "openai";

const execAsync = promisify(exec);

// Initialize OpenAI client
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
});

interface ExecutionResult {
  output: string;
  error?: string;
  executionTime?: number;
}

export async function executeCode(
  code: string, 
  language: string, 
  filename?: string
): Promise<ExecutionResult> {
  const startTime = Date.now();
  
  try {
    switch (language.toLowerCase()) {
      case 'javascript':
      case 'js':
        return await executeJavaScript(code);
      
      case 'typescript':
      case 'ts':
        return await executeTypeScript(code, filename);
      
      case 'python':
      case 'py':
        return await executePython(code, filename);
      
      case 'html':
        return executeHTML(code);
      
      case 'css':
        return executeCSS(code);
      
      case 'json':
        return executeJSON(code);
      
      default:
        return {
          output: `Code execution for ${language} is not supported yet.\n\nSupported languages:\n- JavaScript\n- TypeScript\n- Python\n- HTML\n- CSS\n- JSON`,
          executionTime: Date.now() - startTime
        };
    }
  } catch (error) {
    return {
      output: "",
      error: error instanceof Error ? error.message : "Unknown execution error",
      executionTime: Date.now() - startTime
    };
  }
}

async function executeJavaScript(code: string): Promise<ExecutionResult> {
  try {
    // Create a temporary file
    const tempDir = '/tmp/codewizard';
    if (!existsSync(tempDir)) {
      mkdirSync(tempDir, { recursive: true });
    }
    
    const tempFile = join(tempDir, `script_${Date.now()}.js`);
    writeFileSync(tempFile, code);
    
    const { stdout, stderr } = await execAsync(`node ${tempFile}`, {
      timeout: 10000 // 10 second timeout
    });
    
    // Clean up
    unlinkSync(tempFile);
    
    return {
      output: stdout || stderr || "Code executed successfully with no output."
    };
  } catch (error: any) {
    return {
      output: "",
      error: error.message || "JavaScript execution failed"
    };
  }
}

async function executeTypeScript(code: string, filename?: string): Promise<ExecutionResult> {
  try {
    const tempDir = '/tmp/codewizard';
    if (!existsSync(tempDir)) {
      mkdirSync(tempDir, { recursive: true });
    }
    
    const tempFile = join(tempDir, filename || `script_${Date.now()}.ts`);
    writeFileSync(tempFile, code);
    
    // Compile and run TypeScript
    const { stdout: compileStdout, stderr: compileStderr } = await execAsync(`npx tsc ${tempFile} --outDir ${tempDir} --target es2020 --module commonjs`, {
      timeout: 15000
    });
    
    if (compileStderr && !compileStderr.includes('warning')) {
      unlinkSync(tempFile);
      return {
        output: "",
        error: `TypeScript compilation error: ${compileStderr}`
      };
    }
    
    const jsFile = tempFile.replace('.ts', '.js');
    const { stdout, stderr } = await execAsync(`node ${jsFile}`, {
      timeout: 10000
    });
    
    // Clean up
    unlinkSync(tempFile);
    if (existsSync(jsFile)) {
      unlinkSync(jsFile);
    }
    
    return {
      output: stdout || stderr || "TypeScript code executed successfully with no output."
    };
  } catch (error: any) {
    return {
      output: "",
      error: error.message || "TypeScript execution failed"
    };
  }
}

async function executePython(code: string, filename?: string): Promise<ExecutionResult> {
  try {
    const tempDir = '/tmp/codewizard';
    if (!existsSync(tempDir)) {
      mkdirSync(tempDir, { recursive: true });
    }
    
    const tempFile = join(tempDir, filename || `script_${Date.now()}.py`);
    writeFileSync(tempFile, code);
    
    const { stdout, stderr } = await execAsync(`python3 ${tempFile}`, {
      timeout: 10000
    });
    
    // Clean up
    unlinkSync(tempFile);
    
    return {
      output: stdout || stderr || "Python code executed successfully with no output."
    };
  } catch (error: any) {
    return {
      output: "",
      error: error.message || "Python execution failed"
    };
  }
}

function executeHTML(code: string): ExecutionResult {
  // For HTML, we can validate and provide structure info
  try {
    const hasDoctype = code.toLowerCase().includes('<!doctype');
    const hasHTML = code.toLowerCase().includes('<html');
    const hasHead = code.toLowerCase().includes('<head');
    const hasBody = code.toLowerCase().includes('<body');
    
    let output = "HTML Structure Analysis:\n";
    output += `✓ DOCTYPE declaration: ${hasDoctype ? 'Present' : 'Missing'}\n`;
    output += `✓ HTML tag: ${hasHTML ? 'Present' : 'Missing'}\n`;
    output += `✓ Head section: ${hasHead ? 'Present' : 'Missing'}\n`;
    output += `✓ Body section: ${hasBody ? 'Present' : 'Missing'}\n`;
    
    // Count elements
    const elements = code.match(/<\w+/g);
    const elementCount = elements ? elements.length : 0;
    output += `\n📊 Total HTML elements: ${elementCount}\n`;
    
    output += "\n🎨 HTML code is ready for browser rendering!";
    
    return { output };
  } catch (error) {
    return {
      output: "",
      error: "HTML analysis failed"
    };
  }
}

function executeCSS(code: string): ExecutionResult {
  try {
    const selectors = code.match(/[^{}]+(?=\s*\{)/g) || [];
    const properties = code.match(/[^:;{}]+(?=\s*:)/g) || [];
    
    let output = "CSS Analysis:\n";
    output += `📝 Selectors found: ${selectors.length}\n`;
    output += `🎨 Properties used: ${properties.length}\n`;
    
    if (selectors.length > 0) {
      output += "\n🎯 Selectors:\n";
      selectors.slice(0, 5).forEach((selector, i) => {
        output += `${i + 1}. ${selector.trim()}\n`;
      });
      if (selectors.length > 5) {
        output += `... and ${selectors.length - 5} more\n`;
      }
    }
    
    output += "\n✨ CSS is ready to style your HTML!";
    
    return { output };
  } catch (error) {
    return {
      output: "",
      error: "CSS analysis failed"
    };
  }
}

function executeJSON(code: string): ExecutionResult {
  try {
    const parsed = JSON.parse(code);
    
    let output = "JSON Validation: ✅ Valid JSON\n\n";
    output += "📊 Structure Analysis:\n";
    
    if (Array.isArray(parsed)) {
      output += `Type: Array with ${parsed.length} items\n`;
    } else if (typeof parsed === 'object' && parsed !== null) {
      const keys = Object.keys(parsed);
      output += `Type: Object with ${keys.length} properties\n`;
      if (keys.length > 0) {
        output += "Properties:\n";
        keys.slice(0, 10).forEach(key => {
          const value = parsed[key];
          const type = Array.isArray(value) ? 'array' : typeof value;
          output += `- ${key}: ${type}\n`;
        });
        if (keys.length > 10) {
          output += `... and ${keys.length - 10} more properties\n`;
        }
      }
    } else {
      output += `Type: ${typeof parsed}\n`;
      output += `Value: ${parsed}\n`;
    }
    
    return { output };
  } catch (error) {
    return {
      output: "",
      error: `JSON parsing error: ${error instanceof Error ? error.message : 'Invalid JSON'}`
    };
  }
}

export async function generateAIResponse(message: string, context?: any): Promise<string> {
  try {
    const systemPrompt = `You are a helpful coding assistant for CodeWizard, a development platform. 
    Help users with coding questions, debugging, and best practices. Be concise and practical.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      max_tokens: 1000,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("AI response error:", error);
    return "I'm having trouble generating a response right now. Please try again later.";
  }
}

export async function explainCode(code: string, language: string): Promise<string> {
  try {
    const prompt = `Explain this ${language} code in simple terms. Focus on what it does, how it works, and any important concepts:

\`\`\`${language}
${code}
\`\`\``;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "user", content: prompt }
      ],
      max_tokens: 800,
      temperature: 0.3,
    });

    return response.choices[0].message.content || "I couldn't explain this code. Please try again.";
  } catch (error) {
    console.error("Code explanation error:", error);
    return "I'm having trouble explaining this code right now. Please try again later.";
  }
}