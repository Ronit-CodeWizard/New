import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { FolderOpen, Code, Bot } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-50 to-purple-50 dark:from-dark-bg dark:to-dark-surface"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 dark:text-dark-text mb-6">
              Welcome to <span className="text-brand-500">CodeWizard</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-dark-muted mb-8 max-w-3xl mx-auto">
              Discover, explore, and collaborate on amazing projects. Your gateway to innovative coding solutions and development excellence.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="px-8 py-4 text-lg shadow-lg"
                onClick={() => window.location.href = "/api/login"}
              >
                Get Started
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="px-8 py-4 text-lg border-2"
                onClick={() => window.location.href = "/api/login"}
              >
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50 dark:bg-dark-surface">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-dark-text mb-4">
              Platform Features
            </h2>
            <p className="text-gray-600 dark:text-dark-muted">
              Everything you need for modern development
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-brand-100 dark:bg-brand-500/20 rounded-xl flex items-center justify-center mb-4">
                  <FolderOpen className="h-6 w-6 text-brand-500" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Project Gallery</h3>
                <p className="text-gray-600 dark:text-dark-muted">
                  Browse and explore curated projects from GitHub with live previews and source code access.
                </p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-500/20 rounded-xl flex items-center justify-center mb-4">
                  <Code className="h-6 w-6 text-green-500" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Integrated Editor</h3>
                <p className="text-gray-600 dark:text-dark-muted">
                  Full-featured code editor with syntax highlighting, IntelliSense, and real-time collaboration.
                </p>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-500/20 rounded-xl flex items-center justify-center mb-4">
                  <Bot className="h-6 w-6 text-purple-500" />
                </div>
                <h3 className="text-xl font-semibold mb-2">AI Assistant</h3>
                <p className="text-gray-600 dark:text-dark-muted">
                  Get coding help, suggestions, and explanations from our intelligent AI assistant.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
