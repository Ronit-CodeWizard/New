import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "./components/ThemeProvider";
import { useAuth } from "./hooks/useAuth";
import Navigation from "./components/Navigation";
import FloatingAI from "./components/FloatingAI";
import AppLoader from "./components/AppLoader";
import Landing from "./pages/Landing";
import Home from "./pages/Home";
import Projects from "./pages/Projects";
import Profile from "./pages/Profile";
import Editor from "./pages/Editor";
import Snapshot from "./pages/Snapshot";
import Workspace from "./pages/Workspace";
import Dashboard from "./pages/Dashboard";
import ProjectDetail from "./pages/ProjectDetail";
import Footer from "./components/Footer";
import NotFound from "@/pages/not-found";
import { useEffect, useState } from "react";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/projects" component={Projects} />
          <Route path="/projects/:id" component={ProjectDetail} />
          <Route path="/workspace" component={Workspace} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/profile" component={Profile} />
          <Route path="/editor" component={Editor} />
          <Route path="/snapshot" component={Snapshot} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [showLoader, setShowLoader] = useState(true);

  // Show app loader for 2 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowLoader(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="codewizard-theme">
        <TooltipProvider>
          {showLoader && <AppLoader />}
          <div className={`${showLoader ? 'opacity-0' : 'opacity-100'} transition-opacity duration-500`}>
            <Navigation />
            <main className="pt-16 min-h-screen bg-white dark:bg-dark-bg text-gray-900 dark:text-dark-text">
              <Router />
            </main>
            <Footer />
            <FloatingAI />
          </div>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
